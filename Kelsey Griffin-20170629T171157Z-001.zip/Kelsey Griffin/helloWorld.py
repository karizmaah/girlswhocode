def firstFunction():
    print("This is my first function")

def helloYou(name):
    print("Hello",name)

#print(Happy Friday")
#firstFunction()

#helloYou(Kelsey)

print("WHo are you?")
name = input ()
helloYou(name)
