from PIL import Image


#Import the Image
myImage = Image.open("ok.jpg")
imageData = myImage.getdata()
pixelList = list(imageData)

newPixelList = []

for pixel in pixelList:
    red = pixel[0]
    green = pixel[1]
    blue = pixel[2]


    Intensity = red+green+blue



    if Intensity<182:
        red = 0
        green = 51
        blue = 76
    elif 182<Intensity<364:
        red = 217
        green = 26
        blue = 33
    elif 364<Intensity<520:
        red = 112
        green = 150
        blue = 158
    else:
        red = 252
        green = 227
        blue = 116

    p =(red,green,blue)

    newPixelList.append(p)

    #open the image
newImage = Image.new("RGB",myImage.size)
newImage.putdata(newPixelList)
newImage.show()
