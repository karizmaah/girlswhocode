# importing libraries
from turtle import *
import math

# setting up screen size
setup(700,500)

#FUNCTIONS
def whileDrawShape(turtle,sides,color):
    turtle.pencolor(color)
    drawnSides = 0
    angle = 360/sides

    while drawnSides < sides:
        turtle.forward(50)
        turtle.right(angle)
        drawnSides +=1

def forDrawShape(turtle,sides,color):
    turtle.pencolor(color)
    angle = 360/sides

    for s in range(sides):
        turtle.forward(50)
        turtle.right(angle)


#RUNNINGCODE
anah=Turtle() #creates turtle
anah.turtlesize(2,2) #makes turtle larger
anah.pensize(5) #makes pen larger
anah.pendown()

another = True

while another == True:
    print("How many side do you want?")
    numSides = int(input())

    print("WHat color do you want your shape to have?")
    chosenColor = input()

    forDrawShape(anah,numSides,chosenColor)

    print("Do you want to draw another shape")
    answer = input()

    if(answer == "no"):
        another = False

    if (answer == "yes"):
        anah.penup()
        anah.forward(100)
        anah.pendown()
        


#whileDrawShape(anah,4,"pink")
#anah.penup()
#anah.forward(100)
#anah.pendown()
#forDrawShape(anah,5,"pink")
#whileDrawShape(diana,5,red)


#closes the turtle window on click
exitonclick()
