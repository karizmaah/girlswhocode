from turtle import *
import math

def drawShape(turtle,sides,color):
    turtle.pencolor(color)
    drawnSides = 0
    angle = 360/sides

    while drawnSides < sides:
        turtle.forward(50)
        turtle.right(angle)
        drawnSides+=1

##################################

# RUNNING PROGRAM
another =True

flaritza = Turtle()
flaritza.turtlesize(2,2)
flaritza.pensize(5)
flaritza.pendown()

while another == True:
    
print("How many sides you want?")
numSides = int(input())

print("What color you want?")
chosenColor = input()

drawShape(flaritza,numSides,chosenColor)

print("You want another shape?")
answer =input()
if (answer == "no"):
    another = false
      

exitonclick()
