#groceryList=["cake","juice","lunchables","cookies","avocado"]

#for x in groceryList:
   # print(x)

groceryList = []
add = True

while add == True:
    print("Would you like to add something to your list? You can add milk, cheese, or butter.")

    answer = input()
    milk = answer
    cheese = answer
    butter = answer
    chocolate = answer

    if answer == 'yes':
        print("What would you like?")

    if answer == 'no':
        print("Okay. Too bad.")
        exit()
        
    if answer == 'milk':
        print("That's disgusting, but it's your life.")
        groceryList.append('milk')
        print("Here's your list.")
        for x in groceryList:
            print(x)
    
        

    if answer == 'cheese':
        print("I mean I guess..")
        groceryList.append('cheese')
        print("Here's your list.")
        for x in groceryList:
            print(x)

    if answer == 'chocolate':
        print("If this is Diana, then no.")
        print("Are you Diana?")
    if answer == 'yes':
        exit()
        


